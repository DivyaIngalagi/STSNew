package com.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.model.Order;
import com.spring.service.OrderService;
import com.spring.service.TransactionRequest;
import com.spring.service.TransactionResponse;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
@RequestMapping("/order")
public class OrderController {
	
	@Autowired
	OrderService orderService;
	
	
	@PostMapping("/bookOrder")
	@CircuitBreaker(name="userservice",fallbackMethod = "restCallForOrderService")
	public TransactionResponse bookOrder(@RequestBody TransactionRequest request)
	{
		// give a call to the payment and pass the order id
		return orderService.addOrder(request);
	}
	public String restCallForOrderService(Exception e)
	{
		System.out.println("Hello");
		return "Service is Down";
	}
}
