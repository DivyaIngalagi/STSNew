package com.spring.service;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.spring.model.Order;
import com.spring.model.Payment;
import com.spring.repository.OrderRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class OrderService {
	
	@Autowired
	OrderRepository paymentRepository;
	
	@Autowired
	RestTemplate restTemplate;
	
	
	public TransactionResponse addOrder(TransactionRequest request)
	{
		String message="";
		Order order=request.getOrder();
		Payment payment=request.getPayment();
		payment.setOrderId(order.getId());
		payment.setAmount(order.getPrice());
		
		//rest call
		Payment paymentResponse =restTemplate.postForObject("http://localhost:8282/payment/doPayment", payment, Payment.class);
		message=paymentResponse.getPaymentStatus().equals("success")?"Payment Done Successfully your order is placed": "Payent Not Done Your order is added back to the cart";
		 paymentRepository.save(order);
		 return new TransactionResponse(order,paymentResponse.getAmount(),paymentResponse.getTransactionId(),message);
	}
	
}
