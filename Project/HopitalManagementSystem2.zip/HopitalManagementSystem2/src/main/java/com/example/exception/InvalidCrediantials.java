package com.example.exception;

public class InvalidCrediantials extends RuntimeException {

	public InvalidCrediantials() {
		super("Invalid Credentials");
		// TODO Auto-generated constructor stub
	}

	public InvalidCrediantials(String arg0) {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
