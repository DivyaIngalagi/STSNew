package com.impact.project.service;

import com.impact.project.model.Slot;

public interface SlotService {

	public Slot saveSlot(Slot slot);
}
