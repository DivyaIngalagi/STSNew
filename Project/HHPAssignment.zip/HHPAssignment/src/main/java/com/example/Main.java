package com.example;

public class Main {

    public static void main(String[] args) {
        Assignment1 m = new Assignment1();
        // m.sortFunc1();
        m.sortFunc2();
    }

}
