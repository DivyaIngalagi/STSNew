package com.impact.project.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.impact.project.model.AppointmentSchedule;
import com.impact.project.model.Patient;
import com.impact.project.model.Physician;
import com.impact.project.service.AppointmentScheduleService;
import com.impact.project.service.HospitalService;
import com.impact.project.service.PatientService;
import com.impact.project.serviceImp.AppointmentScheduleServiceImpl;
@CrossOrigin(origins = "http://localhost:8080")
@RestController
@RequestMapping("/appointmentschedule")
public class AppointmentScheduleController {

	@Autowired
	private AppointmentScheduleService appointServ;
	@Autowired
	private PatientService patser;
	@Autowired
	private HospitalService hopser;
	
	@PostMapping("/add")
	public ResponseEntity saveAppointment(@RequestBody AppointmentSchedule appointschedule) {
		
		AppointmentSchedule appSched=appointServ.createAppointment(appointschedule);
		return ResponseEntity.ok("Appointment Saved Successfully:");
	}
	
	@GetMapping("/view/{doctorId}")
	public ResponseEntity getAppointment(@PathVariable int doctorId) {
		
		List<AppointmentSchedule> displayappont = appointServ.displayAppointment(doctorId);	
			return ResponseEntity.ok("The appointnment details are:"+displayappont);
	}
	
	@DeleteMapping("/delete/{appointmentId}")
	public ResponseEntity deleteAppointment(@PathVariable int appointmentId) {
		appointServ.deleteAppointment(appointmentId);
		return ResponseEntity.ok("Appointment Deleted Successfully.");
	}
	
	@PutMapping("/update")
		public ResponseEntity updateAppointment(@RequestBody AppointmentSchedule appointsched) {
			AppointmentSchedule appschedule = appointServ.updateAppointment(appointsched);
			return ResponseEntity.ok("Appointment updated Succesfully."+appschedule);
		}
	
	
	@PostMapping("/patientreg")		
	public ResponseEntity PatientRegPage(@RequestBody Patient patient)
	{	
		Patient pat = patser.savePatient(patient);
		
		return ResponseEntity.ok("Patient has added to DB" +pat);
		
		
	}
	
	@PostMapping("/doctorreg")		
	public ResponseEntity DoctorRegPage(@RequestBody Physician doctor)
	{	
		Physician d = hopser.saveDoctor(doctor);
		
		
		return ResponseEntity.ok("Doctor has added to DB" +d);
		
		
	}
}
