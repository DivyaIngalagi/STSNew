package com.impact.project.service;

import java.util.List;
import java.util.Optional;

import com.impact.project.model.Patient;
import com.impact.project.model.Physician;

public interface PatientService {
	public Patient savePatient(Patient patient);
	
}
