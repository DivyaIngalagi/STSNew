package com.impact.project.exception;

import java.util.Optional;

import com.impact.project.model.AppointmentSchedule;

public class UserNotFoundException extends Exception{

	public UserNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserNotFoundException(String message) {
		super(message);
	}

	
}
