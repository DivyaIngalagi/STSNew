package com.impact.project.serviceImp;

import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.impact.project.exception.UserNotFoundException;
import com.impact.project.model.AppointmentSchedule;
import com.impact.project.repository.AppointmentScheduleRepo;
import com.impact.project.service.AppointmentScheduleService;

@Service
public class AppointmentScheduleServiceImpl implements AppointmentScheduleService {

	@Autowired
	AppointmentScheduleRepo appointRepo;

	@Override
	public AppointmentSchedule createAppointment(AppointmentSchedule appoScheduleCreate) {
		appoScheduleCreate.setDeleted(false);
		return appointRepo.save(appoScheduleCreate);
	}

	@Override
	public List<AppointmentSchedule> displayAppointment(int doctorId) {
		List<AppointmentSchedule> app =  appointRepo.getAllAppointmentRealtedToDoctor(doctorId);
		return app;
		

	}

	@Override
	public void deleteAppointment(int appointmentId) {
		Optional<AppointmentSchedule> appointScheduleDelete = appointRepo.findById(appointmentId);
		appointScheduleDelete.get().setDeleted(true);
		appointRepo.save(appointScheduleDelete.get());

	}

	@Override
	public AppointmentSchedule updateAppointment(AppointmentSchedule appointSchd) {

		Optional<AppointmentSchedule> appoint = appointRepo.findById(appointSchd.getAppointmentId());

		AppointmentSchedule appointSchdUpdate = appoint.get();

		appointSchdUpdate.setAppointmentId(appointSchd.getAppointmentId());
		appointSchdUpdate.setDateofappointment(appointSchd.getDateofappointment());
		appointSchdUpdate.setMeetingdesc(appointSchd.getMeetingdesc());
		appointSchdUpdate.setMeetingtitle(appointSchd.getMeetingtitle());
		appointSchdUpdate.setReason(appointSchd.getReason());
		appointSchdUpdate.setSlotofappointment(appointSchd.getSlotofappointment());
		appointSchdUpdate.setPhysician(appointSchd.getPhysician());
		appointSchdUpdate.setPatient(appointSchd.getPatient());

		return appointRepo.save(appointSchdUpdate);
	}

}
