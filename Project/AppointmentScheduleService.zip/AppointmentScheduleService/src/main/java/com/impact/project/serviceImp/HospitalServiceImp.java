package com.impact.project.serviceImp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.impact.project.model.Physician;
import com.impact.project.repository.HospitalRepository;
import com.impact.project.service.HospitalService;

@Service
public class HospitalServiceImp implements HospitalService {

	@Autowired(required = true) 
	HospitalRepository userrepo;
	@Override
	public Physician saveDoctor(Physician physician) {
		Physician doc = userrepo.save(physician);
		return doc;
	}
}
