package com.impact.project.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Appointment")
public class AppointmentSchedule {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int appointmentId;
	private String meetingtitle;
	private String meetingdesc;
	private String dateofappointment;
	private String slotofappointment;
	private String reason;
	private boolean isDeleted;
	@OneToOne
	@JoinColumn(name = "patient_id")
	private Patient patient;
	@OneToOne
	@JoinColumn(name = "doctor_id")
	private Physician physician;
	@Override
	public String toString() {
		return "AppointmentSchedule [appointmentId=" + appointmentId + ", meetingtitle=" + meetingtitle
				+ ", meetingdesc=" + meetingdesc + ", dateofappointment=" + dateofappointment + ", slotofappointment="
				+ slotofappointment + ", reason=" + reason + ", patient=" + patient + ", physician=" + physician + "]";
	}

	
}
