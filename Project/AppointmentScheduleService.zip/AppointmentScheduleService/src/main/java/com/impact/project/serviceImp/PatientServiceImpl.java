package com.impact.project.serviceImp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.impact.project.model.Patient;
import com.impact.project.repository.PatientRepository;
import com.impact.project.service.PatientService;


@Service
public class PatientServiceImpl implements PatientService {

	@Autowired
	PatientRepository patientrepo;
	
	
	@Override
	public Patient savePatient(Patient patient) {
		Patient pats = patientrepo.save(patient);
		return pats;
	}
	

	
	
}
