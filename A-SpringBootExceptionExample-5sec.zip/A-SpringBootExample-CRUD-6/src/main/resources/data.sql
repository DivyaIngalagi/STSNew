insert into Product values("File1",8000.0, 1);
insert into Product values("File2",89000.0, 5);
insert into Product values("File3",67000.0, 4);
insert into Product values("File4",5000.0, 2);
insert into Product values("File5",600.0, 1)