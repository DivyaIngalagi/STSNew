package com.impact.project.service;

import java.util.List;

import com.impact.project.model.Allergy;

public interface AllergyService {

    List<Allergy> getAllergybyId();

}
