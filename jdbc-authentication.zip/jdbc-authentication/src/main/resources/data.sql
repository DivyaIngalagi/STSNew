INSERT INTO customers VALUES ('alex', '$2a$10$z4KckMZ1HIImE038NnCWKuTDULcEou9zj82ap.sy7gRzDH9lcJlv2', true, 'alex@gmail.com', '8877665544', 'M');

INSERT INTO customers VALUES ('anna', '$2a$10$Rl6gv/kpbwE59uKQXlYhtuX92PES7MxUgiZh.W8nc7weNCFfsryTG', true, 'anna@gmail.com', '9988776655', 'F');

INSERT INTO roles VALUES ('alex', 'ROLE_USER');

INSERT INTO roles VALUES ('anna', 'ROLE_ADMIN');