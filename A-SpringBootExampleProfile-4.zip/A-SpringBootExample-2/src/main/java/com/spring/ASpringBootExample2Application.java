package com.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ASpringBootExample2Application {

	public static void main(String[] args) {
		SpringApplication.run(ASpringBootExample2Application.class, args);
	}

}
