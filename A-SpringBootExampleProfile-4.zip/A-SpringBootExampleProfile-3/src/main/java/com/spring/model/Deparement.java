package com.spring.model;

public interface Deparement {

	 public void Operation();
	 
}
